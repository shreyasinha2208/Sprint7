package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface VerifyPreClosureService {

	List<LoanMaster> getSentForVerificationPreclosure(BankAdmins loggedInBankAdmin);


	
	LoanMaster getLoanByApplicantNum(BigInteger applicantNum);

	CustomerBean getCustomerFromUci(BigInteger uci);

	LoanMaster updatePreClosurePostVerify(LoanMaster globalLoanMaster);



	LoanMaster updatePreClosurePostDenial(LoanMaster globalLoanMaster);
		

}
