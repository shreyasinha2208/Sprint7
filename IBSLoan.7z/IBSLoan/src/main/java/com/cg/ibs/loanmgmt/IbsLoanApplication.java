package com.cg.ibs.loanmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbsLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbsLoanApplication.class, args);
	}

}
