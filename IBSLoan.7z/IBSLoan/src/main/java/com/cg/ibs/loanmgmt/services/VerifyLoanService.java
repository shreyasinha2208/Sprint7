package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface VerifyLoanService {

	List<LoanMaster> getSentForVerificationLoans(BankAdmins loggedInBankAdmin);

	LoanMaster getLoanByApplicantNum(BigInteger applicantNum);

	LoanMaster updateLoanPostVerify(LoanMaster globalLoanMaster);

	LoanMaster updateLoanPostDenial(LoanMaster globalLoanMaster);
	
	public void downloadDocument(LoanMaster loanMaster);

	CustomerBean getCustomerFromUci(BigInteger uci);
		
}
