package com.cg.ibs.loanmgmt.controllers;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.CustomerService;

@RestController
public class DefaultController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private BankAdminService bankAdminService;

	@PostMapping("/checkUser/{role}/{userId}/{password}")
	public ResponseEntity<String> loginRole(@PathVariable("role") String role,@PathVariable("userId") String userId, @PathVariable("password") String password) {
		ResponseEntity<String> result = null;
		
		switch (role) {
		case "CUSTOMER":
			if (customerService.verifyCustomerLogin(userId, password)) {
				result = new ResponseEntity<>("welcome",HttpStatus.OK);
			} else {
				result = new ResponseEntity<>("incorrect credentials",HttpStatus.UNAUTHORIZED);
				
			}
			break;
		case "BANK_ADMIN":
			if (bankAdminService.verifyBankLogin(userId, password)) {
				result = new ResponseEntity<>("welcome",HttpStatus.OK);
			} else {
				result = new ResponseEntity<>("incorrect credentials",HttpStatus.UNAUTHORIZED);
				
			}
			break;
		}
		return result;

	
	}
	
//	@RequestMapping(method = RequestMethod.GET, value = "/failLogin")
//	public ModelAndView loginRole() {
//		ModelAndView modelAndView = new ModelAndView();
//		modelAndView.addObject("message1","Invalid Credentials!");
//		modelAndView.setViewName("errorLoginPage");
//		return modelAndView;
//	}

}
