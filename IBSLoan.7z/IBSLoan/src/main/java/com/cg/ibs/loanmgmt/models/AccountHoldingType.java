package com.cg.ibs.loanmgmt.models;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL;
}
