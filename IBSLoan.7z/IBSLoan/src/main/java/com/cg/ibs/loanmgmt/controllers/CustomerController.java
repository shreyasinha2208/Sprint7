package com.cg.ibs.loanmgmt.controllers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.DocumentBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.ApplyPreClosureService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.PayEmiService;
import com.cg.ibs.loanmgmt.services.ViewHistoryService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private ViewHistoryService viewHistoryService;
	@Autowired
	private ApplyPreClosureService applyPreClosureService;
	@Autowired
	private PayEmiService payEmiService;
	private LoanTypeBean loanTypeBean = new LoanTypeBean();
	CustomerBean customer = new CustomerBean();
	CustomerBean loggedInCustomer = new CustomerBean();
	private LoanMaster globalLoanMaster = new LoanMaster();
	private LoanMaster loanMaster = new LoanMaster();
	private LoanMaster preClosureLoan = new LoanMaster();
	private Account acc = new Account();

	@GetMapping("/customer/{userId}")
	public ResponseEntity<String> loginRole(@PathParam("userId") String userId) {
		ResponseEntity<String> result;
		customer = customerService.getCustomer(userId);

		if (userId == null) {
			result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		} else {
			result = new ResponseEntity<>("Welcome " + customer.getFirstName(), HttpStatus.OK);

		}

		return result;
	}

	@GetMapping(value = "/getLoan/{typeId}")
	public ResponseEntity<LoanTypeBean> getDetailsForLoan(@PathParam("typeId") Integer typeId) {
		ResponseEntity<LoanTypeBean> result;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);

		if (typeId == null) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
			result = new ResponseEntity<>(loanTypeBean, HttpStatus.OK);
		}

		return result;

	}

	@GetMapping(value = "/calculateEMI/{typeId}/{loanAmount}/{loantenure}")
	public ResponseEntity<String> calculateEmi(@PathParam("typeId") Integer typeId,
			@PathParam("loanAmount") BigDecimal loanAmount, @PathParam("loanTenure") Integer loanTenure) {
		ResponseEntity<String> result;
		globalLoanMaster.setTypeId(typeId);
		System.out.println(globalLoanMaster.getTypeId());
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
		globalLoanMaster.setLoanAmount(loanAmount);
		globalLoanMaster.setBalance(globalLoanMaster.getLoanAmount());
		globalLoanMaster.setLoanTenure(loanTenure);
		try {
		globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(globalLoanMaster).getEmiAmount());
		result = new ResponseEntity<>("EMI Amount:"+globalLoanMaster.getEmiAmount(), HttpStatus.OK);
		}catch (Exception exc) {
			result=new ResponseEntity<String>("Invalid entry",HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@GetMapping(value = "/savingsAccountDetails/{userId}")
	public ResponseEntity<Set<AccountHolding>> getSavingsAccount(@PathVariable("userId") String userId) {
		ResponseEntity<Set<AccountHolding>> result;
		System.out.println(userId);
		loggedInCustomer = customerService.getCustomer(userId);
		System.out.println(loggedInCustomer.getUci());
		System.out.println(applyLoanService.getSavingAccountListByUci(loggedInCustomer));
		System.out.println("Hiiiiiiiiiiiiiiiiiiiiiiiii");
		result = new ResponseEntity(applyLoanService.getSavingAccountListByUci(loggedInCustomer), HttpStatus.OK);
		return result;
	}

	@PutMapping(value = "/loanApplied/{accNo}")
	public ResponseEntity<String> applyLoan(@PathVariable("accNo") BigInteger accNo,
			@RequestBody LoanMaster loanMaster) {
		ResponseEntity<String> result;

		globalLoanMaster.setStatus(LoanStatus.DOCUMENT_PENDING);
		globalLoanMaster.setBalance(globalLoanMaster.getLoanAmount());
		System.out.println(globalLoanMaster.getLoanAmount());
		globalLoanMaster.setAppliedDate(LocalDate.now());
		globalLoanMaster.setUci(loggedInCustomer.getUci());
		applyLoanService.sendLoanForVerification(globalLoanMaster, accNo);

		result = new ResponseEntity<>(
				"Loan has been applied and application number is" + globalLoanMaster.getApplicationNumber(),
				HttpStatus.OK);
		return result;
	}

	@GetMapping("/payEmiHomePage/{userName}")
	public void getCustomerByUserId(@PathVariable("userName") String userId) {
		customer = payEmiService.getCustomer(userId);
	}

	@GetMapping("/viewLoansForEmi/{userId}")
	public ResponseEntity<List<LoanMaster>> viewLoansForEmi(@PathVariable("userId") String userId) {
		ResponseEntity<List<LoanMaster>> result;

		List<LoanMaster> loansForEmiList = new ArrayList<LoanMaster>();
		loansForEmiList = payEmiService.getApprovedLoanListByUci(customer);
		for (LoanMaster loanMaster : loansForEmiList) {
			System.out.println(loanMaster.getLoanAccountNumber() + "\t" + loanMaster.getNumOfEmisPaid() + "\t"
					+ loanMaster.getTypeId() + "\t" + loanMaster.getEmiAmount() + "\t" + loanMaster.getNextEmiDate());
		}
		result = new ResponseEntity<List<LoanMaster>>(loansForEmiList, HttpStatus.OK);
		return result;
	}

	@GetMapping("/selectLoanForEmi")
	public ResponseEntity<String> selectLoanForEmi(@PathVariable("loanNumber") BigInteger loanNo) {
		ResponseEntity<String> result1;
		LoanMaster loanForEmi = payEmiService.getLoanByLoanNum(loanNo);
		if (loanNo == null) {
			result1 = new ResponseEntity<>("No Loan Number Received", HttpStatus.BAD_REQUEST);
		} else if (loanForEmi == null) {
			result1 = new ResponseEntity<>("Invalid Loan Number entered", HttpStatus.NO_CONTENT);
		} else {
			result1 = new ResponseEntity<>(loanForEmi.toString(), HttpStatus.OK);
		}
		return result1;
	}

	@GetMapping("/emiPaymentChoice")
	public ResponseEntity<String> emiPaymentChoice(@PathVariable("emiPayChoice") Integer choice,
			@PathVariable("loanNumber") BigInteger loanNo) {
		ResponseEntity<String> result2 = null;
		loanMaster = payEmiService.getLoanByLoanNum(loanNo);
		switch (choice) {
		case 1:
			if (loanMaster.getNextEmiDate().until(LocalDate.now(), ChronoUnit.DAYS) <= 3) {
				result2 = new ResponseEntity<>("EMI Payment Successful", HttpStatus.OK);
				loanMaster.setNumOfEmisPaid(loanMaster.getNumOfEmisPaid() + 1);
				loanMaster.setNextEmiDate(loanMaster.getNextEmiDate().plusMonths(1));
			} else {
				result2 = new ResponseEntity<>("EMI already paid for this month.", HttpStatus.OK);
			}
			break;
		case 2:
			result2 = new ResponseEntity<>("Thank You! Please pay your next EMI on time.", HttpStatus.OK);
			break;
		default:
			result2 = new ResponseEntity<>("Invalid choice", HttpStatus.BAD_REQUEST);
		}
		return result2;
	}

	@GetMapping("/viewPendingLoans")
	public ResponseEntity<List<LoanMaster>> viewPendingLoans(@PathVariable("userName") String userId) {
		ResponseEntity<List<LoanMaster>> result4;
		customer = viewHistoryService.getCustomer(userId);
		List<LoanMaster> pendingLoans = viewHistoryService.getAllLoans(customer);
		result4 = new ResponseEntity(pendingLoans, HttpStatus.OK);
		return result4;
	}

	@GetMapping("/viewSortedLoans")
	public ResponseEntity<List<LoanMaster>> viewSortedLoans(@PathVariable("userName") String userId,
			@PathVariable("sortingChoice") String sortingChoice) {
		ResponseEntity<List<LoanMaster>> result5;
		customer = viewHistoryService.getCustomer(userId);
		List<LoanMaster> pendingLoans = viewHistoryService.getAllLoans(customer);
		List<LoanMaster> sortedLoans = viewHistoryService.sortLoans(pendingLoans, sortingChoice);
		result5 = new ResponseEntity<List<LoanMaster>>(sortedLoans, HttpStatus.OK);
		return result5;
	}

	@GetMapping(value = "/showPreClosureList")
	public ResponseEntity<List<LoanMaster>> showPreClosureLoans() {
		ResponseEntity<List<LoanMaster>> result;
		List<LoanMaster> preClosureList = new ArrayList<>();
		List<LoanMaster> listTemp = new ArrayList<>();
		listTemp = applyPreClosureService.getApprovedLoanListByUci(loggedInCustomer);
		if (listTemp.isEmpty()) {
			result = new ResponseEntity<List<LoanMaster>>(HttpStatus.NOT_FOUND);
		} else {
			for (LoanMaster loanMaster : listTemp) {
				if (loanMaster.getStatus().equals(LoanStatus.APPROVED)) {
					preClosureList.add(loanMaster);

				}
			}
			result = new ResponseEntity<List<LoanMaster>>(preClosureList, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("/applyPreClosure")
	public ResponseEntity<String> applyPreclosure(@PathVariable("loanAccNumber") BigInteger loanAccNumber) {
		ResponseEntity<String> result;
		globalLoanMaster.setLoanAccountNumber(loanAccNumber);
		if (loanAccNumber == null) {
			result = new ResponseEntity<>("No such Loan Account Number is present", HttpStatus.NOT_FOUND);
		} else {
			preClosureLoan = applyPreClosureService.getLoanDetails(globalLoanMaster.getLoanAccountNumber());
			applyPreClosureService.updatePreClosure(preClosureLoan);
			result = new ResponseEntity<String>("Your loan has been sent for PreClosure Verification", HttpStatus.OK);
			return result;
		}
		return result;
	}
}
