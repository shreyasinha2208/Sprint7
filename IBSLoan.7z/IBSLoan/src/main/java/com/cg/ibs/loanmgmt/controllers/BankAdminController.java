package com.cg.ibs.loanmgmt.controllers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.VerifyLoanService;
import com.cg.ibs.loanmgmt.services.VerifyPreClosureService;

@RestController
@Scope("session")
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	@Autowired
	private VerifyLoanService verifyLoanService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private VerifyPreClosureService verifyPreclosureService;

	BankAdmins loggedInBankAdmin = new BankAdmins();
	LoanMaster globalLoanMaster = new LoanMaster();

	@GetMapping("/bankAdmin/{userId}")
	public ResponseEntity<String> loginRole(@PathVariable("userId") String userId) {
		ResponseEntity<String> result;
		loggedInBankAdmin = bankAdminService.getBankAdmin(userId);
		if (userId == null) {
			result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		} else {
			result = new ResponseEntity<>("Welcome " + loggedInBankAdmin.getAdminId(), HttpStatus.OK);

		}

		return result;
	}

	@GetMapping(value = "/verifyLoan")
	public ResponseEntity<List<LoanMaster>> viewPendingLoans() {
		ResponseEntity<List<LoanMaster>> result;
		try {
			List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
			result = new ResponseEntity<List<LoanMaster>>(pendingLoans, HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<List<LoanMaster>>(HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@GetMapping(value = "/verifyLoan/{custUci}")
	public ResponseEntity<CustomerBean> sendCustomerDetails(@PathVariable("custUci") BigInteger uci) {
		ResponseEntity<CustomerBean> result;
		try {
			List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
			CustomerBean cust = verifyLoanService.getCustomerFromUci(uci);
			result = new ResponseEntity<>(cust, HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		return result;

	}

//	@RequestMapping(value = "/verifyLoan/{appNo}")
//	public ModelAndView selectLoanVerify(@RequestParam("appNo") BigInteger appNo) {
//		globalLoanMaster.setApplicationNumber(appNo);
//		ModelAndView mv5 = new ModelAndView();
//		List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
//		mv5.addObject("pendingLoans", pendingLoans);
//		mv5.addObject("lApplicationNo", loanApplicationNumber);
//		mv5.setViewName("verifyLoanPage");
//		return mv5;
//	}
//
//	@RequestMapping(value = "/verifyLoan3")
//	public ModelAndView viewCompleteDetails() {
//		ModelAndView mv6 = new ModelAndView();
//		globalLoanMaster = verifyLoanService.getLoanByApplicantNum(globalLoanMaster.getApplicationNumber());
//		mv6.addObject("lMaster", globalLoanMaster);
//		mv6.setViewName("verifyLoanPage");
//		return mv6;
//	}

//	@RequestMapping(value = "/verifyLoan4")
//	public ModelAndView downloadDoc() {
//		return null;
//	}

	@PutMapping(value = "/approveLoan")
	public ResponseEntity<String> updateLoanPostVerify(@RequestParam("appNo") BigInteger appNo) {
		ResponseEntity<String> result;

		globalLoanMaster.setStatus(LoanStatus.APPROVED);
		globalLoanMaster.setApprovedDate(LocalDate.now());
		globalLoanMaster.setNextEmiDate(LocalDate.now().plusMonths(1));
		globalLoanMaster.setTotalNumOfEmis(globalLoanMaster.getLoanTenure());
		globalLoanMaster.setNumOfEmisPaid(0);
		globalLoanMaster.getSavingsAccount().setBalance(globalLoanMaster.getLoanAmount());
		try {
			globalLoanMaster = verifyLoanService.updateLoanPostVerify(globalLoanMaster);
			result = new ResponseEntity<String>(
					"Loan has been approved. your loan number is:" + globalLoanMaster.getLoanAccountNumber(),
					HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<String>("Some error has occured", HttpStatus.CONFLICT);
		}
		return result;
	}

	@PutMapping(value = "/denyLoan")
	public ResponseEntity<String> updateLoanPostDeny(@RequestParam("appLoan") Integer choice) {
		ResponseEntity<String> result;
		try {
			globalLoanMaster.setStatus(LoanStatus.DENIED);
			globalLoanMaster = verifyLoanService.updateLoanPostDenial(globalLoanMaster);
			result = new ResponseEntity<String>("Loan has been denied", HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<String>("Some error has occured", HttpStatus.CONFLICT);
		}
		return result;
	}

	@GetMapping(value = "/verifyPreclosure")
	public ResponseEntity<List<LoanMaster>> viewPendingPreClosure() {
		ResponseEntity<List<LoanMaster>> result;
		try {
			List<LoanMaster> pendingPreclosure = verifyPreclosureService
					.getSentForVerificationPreclosure(loggedInBankAdmin);
			result = new ResponseEntity<List<LoanMaster>>(pendingPreclosure, HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<List<LoanMaster>>(HttpStatus.BAD_REQUEST);
		}

		return result;
	}
	
	@GetMapping(value = "/verifyPreClosure/{custUci}")
	public ResponseEntity<CustomerBean> sendCustomerPreClosureDetails(@PathVariable("custUci") BigInteger uci) {
		ResponseEntity<CustomerBean> result;
		try {
			List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
			CustomerBean cust = verifyPreclosureService.getCustomerFromUci(uci);
			result = new ResponseEntity<>(cust, HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		return result;

	}
	
	@PutMapping(value = "/approvePreClosure")
	public ResponseEntity<String> updatePreClosurePostVerify(@RequestParam("appNo") BigInteger appNo) {
		ResponseEntity<String> result;
		globalLoanMaster.setLoanClosedDate(LocalDate.now());
		globalLoanMaster.setStatus(LoanStatus.PRE_CLOSED);
		globalLoanMaster.setBalance(new BigDecimal("0.00"));
		globalLoanMaster.setNextEmiDate(null);

		try {
			globalLoanMaster = verifyPreclosureService.updatePreClosurePostVerify(globalLoanMaster);
			result = new ResponseEntity<String>(
					"Your PreClosure has been approved and the details have been updated." + globalLoanMaster.getLoanAccountNumber(),
					HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<String>("Some error has occured", HttpStatus.CONFLICT);
		}
		return result;
	}

	@PutMapping(value = "/denyPreClosure")
	public ResponseEntity<String> updatePreClosurePostDeny(@RequestParam("appLoan") Integer choice) {
		ResponseEntity<String> result;
		try {
			globalLoanMaster.setStatus(LoanStatus.APPROVED);
			globalLoanMaster.setNextEmiDate(globalLoanMaster.getNextEmiDate());
			globalLoanMaster = verifyLoanService.updateLoanPostDenial(globalLoanMaster);
			result = new ResponseEntity<String>("PreClosure has been denied", HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<String>("Some error has occured", HttpStatus.CONFLICT);
		}
		return result;
	}

	
}
